%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Flight Simulation Model
% AERO5750
% Author: 430407055 DONG HYEOK PARK
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; clc; close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%% INPUT DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Read Data from Motive
FlightData = csvread('Test1_002_AERO5750(35s-1m15s)(rpt).csv',7,1);              % Flight log

% Replace Zeros with Nan
[r,c] = size(FlightData);
for i = 1:r
    for j = 1:c
        
        if FlightData(i,j) == 0
            FlightData(i,j) = nan;
        end
    end
end

T = FlightData(:,1);                                    % Time frame
Quat = FlightData(:,[2 3 4 5]);                         % Quaternians
Pos = FlightData(:,[6 8 7]);                            % Position [XYZ]

% Quaternians to Euler Angle
Euler = Q2E(Quat);                                        % [phi psi theta]

% Extract bank angle from 39s - 43s
% This is when stick impulse was applied
ind1 = find(T==39);
ind2 = find(T==43);
phi_extract = Euler((ind1:ind2),1);
idx = ~isnan(phi_extract);
T_extract = T(ind1:ind2);
% Continued Data (phi) without NANs
T_phi = T_extract(idx,1);
phi = phi_extract(idx,1);

% Fourier Transformation and Laplace Transform
phi_FT = fit(T_phi, phi, 'fourier2');
syms x
phi_tdomain = phi_FT.a0 + phi_FT.a1*cos(x*phi_FT.w) + phi_FT.b1*sin(x*phi_FT.w) + ...
               phi_FT.a2*cos(2*x*phi_FT.w) + phi_FT.b2*sin(2*x*phi_FT.w);
phi_sdomain = laplace(phi_tdomain);

% Define Transfer function
Gphidroll = tf([0 ,0, 13879568927709308591936458255457], [20282409603651670423947251286016, 0, 18766841653461987891556684887409/5070602400912917605986812821504])...
- tf([0, 184452493753967, 0], [4503599627370496, 0, 18766841653461987891556684887409/1267650600228229401496703205376])...
- tf([0, 5017710452550899, 0], [576460752303423488, 0, 18766841653461987891556684887409/5070602400912917605986812821504])...
- tf([0, 0, 5488444411452011168886779151315], [10141204801825835211973625643008, 0, 18766841653461987891556684887409/1267650600228229401496703205376])...
+ tf([0, 641171026445339], [9007199254740992, 0]);

% Final TF of droll to phi
Gphidroll = zpk(Gphidroll);

% Extract pitch angle from 51s - 55s
% ind3 = find(T==51);
% ind4 = find(T==55);
% theta = Euler((ind3:ind4),3);

%% Plotting

% phi, theta, psi
figure;
plot(T(6307:15802), unwrap(Euler(6307:15802,1)));
hold on;
grid minor;
plot(T(6307:15802), unwrap(Euler(6307:15802,2)));
plot(T(6307:15802), unwrap(Euler(6307:15802,3)));
legend('phi', 'psi', 'theta');

% Extracted phi
figure;
plot(T_phi,unwrap(phi));
hold on;
grid minor;
plot(phi_FT);
legend('Real-time Response', 'Fourier Transform');

% Input for TF roll to phi
figure;
opt = stepDataOptions('InputOffset',0,'StepAmplitude',0.1);
impulse(Gphidroll, 20, opt);
grid minor;
legend('Phi response');

% X, Y, Z
figure;
plot(T(6307:15802), Pos(6307:15802,1));
hold on;
grid minor;
plot(T(6307:15802), Pos(6307:15802,2));
plot(T(6307:15802), Pos(6307:15802,3));
legend('X', 'Y', 'Z');

% 3D plotting
figure;
plot3(Pos(6307:15802,1), Pos(6307:15802,2), Pos(6307:15802,3), '-o','MarkerIndices',1);
grid minor;
xlabel('X');
ylabel('Y');
zlabel('Z');





